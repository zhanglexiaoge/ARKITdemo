//
//  ViewController.h
//  AR的录屏demo(有声音)
//
//  Created by LJP on 13/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//


#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)

#import "ViewController.h"
#import "JPARRecord.h"

//遵循代理
@interface ViewController () <ARSessionDelegate,ARSCNViewDelegate,JPARRecordDelegate>

@property (nonatomic, strong) IBOutlet ARSCNView *sceneView;

@property (nonatomic, strong) JPARRecord * arRecord;

@end

@implementation ViewController

#pragma mark ======================================= 生命周期 =======================================

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initData];
    [self initUI];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    ARWorldTrackingConfiguration * configuration = [[ARWorldTrackingConfiguration alloc]init];
    [self.sceneView.session runWithConfiguration:configuration];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.sceneView.session pause];
}


#pragma mark ======================================= 私有方法 =======================================

- (void)initData {
    self.arRecord = [[JPARRecord alloc]init];
    self.arRecord.delegate = self;
}

- (void)initUI {
    
    CGRect bounds = [UIScreen mainScreen].bounds;
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(bounds.size.width/2-60, bounds.size.height - 200, 120, 100)];
    [button setTitle:@"开始录制" forState:UIControlStateNormal];
    [button setTitle:@"正在录制" forState:UIControlStateSelected];
    [button addTarget:self action:@selector(clicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    [self initSceneView];
    
}

//点击按钮
-(void)clicked:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    
    if (sender.selected) {
        [self.arRecord startRecording];
    }else {
        [self.arRecord endRecording];
    }
    
}

- (void)initSceneView {
    
    self.sceneView.showsStatistics = YES;
    
    SCNScene *scene = [SCNScene new];
    
    self.sceneView.scene = scene;
    self.sceneView.session.delegate = self;
    self.sceneView.delegate = self;
    
    SCNScene * idleScene = [SCNScene sceneNamed:@"art.scnassets/twist_danceFixed.dae"];
    
    SCNNode * node = [[SCNNode alloc]init];
    for (SCNNode * child in idleScene.rootNode.childNodes) {
        [node addChildNode:child];
    }
    
    node.position = SCNVector3Make(0, -0.8, -1.6); //3D模型的位置
    node.scale    = SCNVector3Make(0.2, 0.2, 0.2); //模型的大小
    
    [self.sceneView.scene.rootNode addChildNode:node];
    
    self.arRecord.renderer.scene = self.sceneView.scene;
    
}


- (void)endMerge {
    
    //初始化警告框
    UIAlertController*alert = [UIAlertController
                               alertControllerWithTitle: @"提示"
                               message: @"视频已经保存到相册"
                               preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction
                      actionWithTitle:@"确定"
                      style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                      {
                      }]];
    
    //弹出提示框
    [self presentViewController:alert animated:YES completion:nil];
    
}



@end

