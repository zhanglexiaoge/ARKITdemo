//
//  ViewController.m
//  第三次敲这个代码
//
//  Created by jp on 4/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import "ViewController.h"

//导入框架
#import <ARKit/ARKit.h>
#import <SceneKit/SceneKit.h>

@interface ViewController () <ARSCNViewDelegate>

//视图
@property(nonatomic, strong) ARSCNView * jpARSCNView;

//会话
@property(nonatomic, strong) ARSession * jpARSession;

//跟踪会话
@property(nonatomic, strong) ARWorldTrackingConfiguration * jpARWTkConfiguration;

@end

    
@implementation ViewController


#pragma mark - 生命周期

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self.view addSubview:self.jpARSCNView];
    
    //场景运行并且设置跟踪会话
    [self.jpARSession runWithConfiguration:self.jpARWTkConfiguration];
    
    [self addNode];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    
    self.jpARWTkConfiguration = nil;
    self.jpARSession = nil;
    self.jpARWTkConfiguration = nil;
    
}

#pragma mark - 私有方法

- (void)addNode{
    
    SCNScene * jpSCNScene1 = [SCNScene sceneNamed:@"cup.scnassets/candle/candle.scn"];
    SCNScene * jpSCNScene2 = [SCNScene sceneNamed:@"art.scnassets/ship.scn"];
    SCNScene * jpSCNScene3 = [SCNScene sceneNamed:@"AAA.scnassets/chair/chair.scn"];
    
    //创建容器的时候 自动创建了根节点
    SCNNode * planeNode1 = jpSCNScene1.rootNode.childNodes[0];
    SCNNode * planeNode2 = jpSCNScene2.rootNode.childNodes[0];
    SCNNode * planeNode3 = jpSCNScene3.rootNode.childNodes[0];

    //设置位置
    planeNode1.position = SCNVector3Make(-0.5, -1, -1);
    planeNode2.position = SCNVector3Make(0, -1, -1);
    planeNode3.position = SCNVector3Make(1, -1, -1);

    //设置节点
    [self.jpARSCNView.scene.rootNode addChildNode:planeNode1];
    [self.jpARSCNView.scene.rootNode addChildNode:planeNode2];
    [self.jpARSCNView.scene.rootNode addChildNode:planeNode3];
}


#pragma mark - 访问器方法

- (ARSCNView *)jpARSCNView {
    
    if (_jpARSCNView == nil) {
        _jpARSCNView = [[ARSCNView alloc]init];
        _jpARSCNView.frame = self.view.frame;
        _jpARSCNView.session = self.jpARSession;
        _jpARSCNView.automaticallyUpdatesLighting = YES;
        
    }
    
    return _jpARSCNView;
}

- (ARSession *)jpARSession {
    
    if (_jpARSession == nil) {
        _jpARSession = [[ARSession alloc]init];
    }
    
    return _jpARSession;
    
}

- (ARWorldTrackingConfiguration *)jpARWTkConfiguration {
    
    if (_jpARWTkConfiguration == nil) {
        _jpARWTkConfiguration = [[ARWorldTrackingConfiguration alloc]init];
        _jpARWTkConfiguration.planeDetection = ARPlaneDetectionHorizontal;
        _jpARWTkConfiguration.lightEstimationEnabled = YES;
    
    }
    
    return _jpARWTkConfiguration;
    
}

@end
