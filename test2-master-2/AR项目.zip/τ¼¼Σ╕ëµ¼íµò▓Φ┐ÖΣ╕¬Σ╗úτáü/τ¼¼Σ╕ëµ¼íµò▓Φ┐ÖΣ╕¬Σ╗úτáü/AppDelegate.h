//
//  AppDelegate.h
//  第三次敲这个代码
//
//  Created by LJP on 4/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

